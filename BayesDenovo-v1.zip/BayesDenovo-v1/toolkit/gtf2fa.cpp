#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <list>
#include <math.h>
#include <algorithm>
#include <vector>
#include <sstream>
#include <set>
#include <map>
#include <limits.h>
#include <assert.h>
using namespace std;

void print_exon(vector<vector<int> > &exon, map<int,string> &famap, ofstream &outfile, double l_th, string trans_id);

int main(int argc, char *argv[])
{
	string fafile = argv[1];
	string gtffile = argv[2];
	string outfilename = argv[3];
	double l_th = 300;
	if (argc == 5)
	{
		string l_th_str = argv[4];
		l_th = atof(l_th_str.c_str());
	}
	ifstream infile1, infile2;
	infile1.open(fafile.c_str());
	string line;
	string chrline;
	map<int,string> famap;
	int countline = 0;
	int prefix = -1;
	if (infile1.is_open())
	{
		while (infile1.good())
		{
			getline(infile1,line);
			if (line[0] == '>')
			{
				if (countline > 0)
				{
					assert(prefix > 0);
					famap[prefix] = chrline;
					//cout << chrline << endl;
				}
				prefix = atoi(line.substr(1).c_str());
				chrline = "";
			}
			else
			{
				chrline += line;
			}
			if (line.empty())
				famap[prefix]= chrline;
			countline++;
		}
	}

	//for (map<int,string>::iterator it = famap.begin(); it != famap.end(); it++)
	//{
	//	cout << it->first << endl;
	//}
	infile2.open(gtffile.c_str());
	ofstream outfile(outfilename.c_str());
	string trans_id = "";
	string pre_trans_id = "";
	vector<vector<int> > exon;
	countline = 0;
	if (infile2.is_open())
	{
		while (infile2.good())
		{
			getline(infile2,line);
			int s1,s2;
			char info_char[1000], type[100];
			sscanf(line.c_str(),"%*s\t%*s\t%s\t%d\t%d\t%*s\t%*s\t%*s\t%*s%*s%*s%s",type,&s1,&s2,info_char);
			string type_str = type;
			string info_str = info_char;
			if (type_str != "exon")
				continue;
			trans_id = info_str.substr(1,info_str.size()-3);
			//cout << trans_id << endl;
			vector<int> single_exon;
			single_exon.push_back(s1);
			single_exon.push_back(s2);
			if (trans_id == pre_trans_id)
			{
				exon.push_back(single_exon);
			}
			else
			{
				if (countline > 0)
				{
					//outfile << ">" << pre_trans_id << endl;
					print_exon(exon,famap,outfile,l_th,pre_trans_id);	
				}	
				pre_trans_id = trans_id;
				exon.clear();
				exon.push_back(single_exon);
			}
			if (line.empty())
			{
				//outfile << ">" << trans_id << endl;
				print_exon(exon,famap,outfile,l_th,pre_trans_id);	
			}
			countline++;
		}
	}


	return 0;
}

void print_exon(vector<vector<int> > &exon, map<int,string> &famap, ofstream &outfile, double l_th, string trans_id)
{
	stringstream m;
	assert(exon.size() > 0);
	map<int,string>::iterator it = famap.lower_bound(exon[0][0]);
	if (it->first > exon[0][0])
		advance(it,-1);
	string fa = it->second;
	int count = 0;
	for(int i = 0; i < exon.size(); i++)
	{
		for (int j = exon[i][0]; j <= exon[i][1]; j++)
		{
			int pos = j - it->first;
			if (fa[pos] != 'N')
			{
				m << fa[pos];
				count++;
			}
			if ((count)%60 == 0)
				m << endl;
		}
	}
	if (m.str().size()>l_th)
	{
		outfile << ">" << trans_id << endl;
		outfile << m.str();
		outfile << endl;
	}
	//return m.str();
}