#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <list>
#include <math.h>
#include <algorithm>
#include <vector>
#include <sstream>
#include <set>
#include <map>
#include <limits.h>
#include <assert.h>
using namespace std;

void print_exon(vector<vector<int> > &exon, map<int,string> &famap, ofstream &outfile);

int main(int argc, char *argv[])
{
	string instfile = argv[1];
	string gtffile = argv[2];
	string cov = argv[3];
	double l_th = 300;
	if (argc == 5)
	{
		string l_th_str = argv[4];
		l_th = atof(l_th_str.c_str());
	}
	double cov_th = atof(cov.c_str());
	ifstream infile1;
	infile1.open(instfile.c_str());
	ofstream outfile(gtffile.c_str());
	vector<vector<int> > exon;
	string line;
	int instcount = 1;
	if (infile1.is_open())
	{
		while (infile1.good())
		{
			getline(infile1,line);
			
			if (line[0] == '@')
				continue;
			int idx = line.find_first_of('\t');
			string label = line.substr(0,idx);
			//cout << label << "\t" << idx << endl;
			//int aa;
			//cin >> aa;
			if (label == "Instance")
			{
				//cout << instcount << endl;
				getline(infile1,line);
				if(line[line.size()-1] == '.')
				{
					getline(infile1,line);
					getline(infile1,line);//Segs
					idx = line.find_last_of('\t');
					int Nsegs = atoi(line.substr(idx+1).c_str());
					double allcov = 0;
					double trans_l = 0;
					for (int i = 0; i < Nsegs; i++)
					{
						vector<int> single_exon;
						getline(infile1,line);
						idx = line.find_first_of('\t');
						int s1 = atoi(line.substr(0,idx).c_str());
						int idx1 = line.find_first_of('\t',idx+1);
						int s2 = atoi(line.substr(idx+1,idx1-idx-1).c_str());
						idx = line.find_last_of('\t');
						double cov = atof(line.substr(idx+1).c_str());
						allcov += cov;
						single_exon.push_back(s1);
						single_exon.push_back(s2);
						exon.push_back(single_exon);
						trans_l += s2 - s1 + 1;
					}
					if (allcov / Nsegs >= cov_th and trans_l > l_th)
					{
						stringstream genename;
						genename << "graph_single_" << instcount << "_plus";
						for(int i = 0; i < Nsegs; i++)
						{
							stringstream transid;
							transid << genename.str() << "_seq" << i;
							outfile << "chr1\tBayesembler_single\texon\t" << exon[i][0] << "\t" << exon[i][1] << "\t.\t+\t.\tgene_id \"" << genename.str() << "\"; ";
							outfile << "transcript_id \"" << transid.str() << "\"; " << endl;
						}
						instcount++;
					}
					exon.clear();
				}

			}
		}
	}


	return 0;
}