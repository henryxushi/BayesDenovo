PKG_PATH=WHERE_PKG_INSTALLED

chmod -R a+x $PKG_PATH/toolkit/
chmod -R a+x $PKG_PATH/src/
chmod -R a+x $PKG_PATH/plugins/

OUTPATH=$PKG_PATH/demo/output
kmer=25
seqType=fq # use fq for fastq file and fa for fasta file

LEFT=$PKG_PATH/demo/reads.left.fq 
RIGHT=$PKG_PATH/demo/reads.right.fq

nCPU=5 #number of cores

export LD_LIBRARY_PATH=$PKG_PATH/lib:$LD_LIBRARY_PATH
export PATH=$PKG_PATH/toolkit:$PATH


$PKG_PATH/BayesDenovo_v1.pl -k $kmer  --seqType $seqType --left $LEFT --right $RIGHT --CPU $nCPU --output $OUTPATH --bamfile $OUTPATH/bayesdenovo.sam --fafile $OUTPATH/bayesdenovo.fa

